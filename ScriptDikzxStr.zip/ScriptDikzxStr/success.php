<?php
include 'shortlink.php';
$subdomain = $_GET['folder'] ?? 'folder_not_found';
$domain = $_SERVER['DIKZX_STR'];
$longURL = $domain . '/' . $subdomain;
$shortenedURL = shortenURL($longURL);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Link Success | Cahyo SR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap');

        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e9edf2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }

        .card-premium {
            background: white;
            border-radius: 2rem;
            max-width: 480px;
            width: 100%;
            padding: 2.5rem;
            text-align: center;
            position: relative;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
        }

        .icon-success {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border-radius: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.3);
        }

        .gradient-text {
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 800;
        }

        .input-group {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 1rem;
            padding: 0.75rem 1rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            text-align: left;
        }

        .input-group:focus-within {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        .label-style {
            display: block;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            margin-bottom: 0.5rem;
            text-align: left;
        }

        .input-box {
            background: transparent;
            border: none;
            color: #1e293b;
            width: 100%;
            font-size: 0.85rem;
            font-weight: 500;
            outline: none;
        }

        .input-box:read-only {
            cursor: pointer;
        }

        .btn-gradient {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            color: white;
            font-weight: 700;
            border-radius: 1rem;
            padding: 1rem;
            width: 100%;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            border: none;
            cursor: pointer;
        }

        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.4);
        }

        .btn-outline {
            background: white;
            border: 1px solid #e2e8f0;
            color: #475569;
            font-weight: 600;
            border-radius: 1rem;
            padding: 1rem;
            width: 100%;
            margin-top: 0.75rem;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            cursor: pointer;
        }

        .btn-outline:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }

        #toast {
            position: fixed;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%) translateY(20px);
            background: #1e293b;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 1rem;
            font-weight: 500;
            font-size: 0.85rem;
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 10000;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
            white-space: nowrap;
        }

        #toast.show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }

        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 1.5rem 0 1rem;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #e2e8f0;
        }

        .divider span {
            padding: 0 1rem;
            color: #94a3b8;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .short-link {
            background: #f1f5f9;
            border-radius: 0.75rem;
            padding: 0.5rem 0.75rem;
            font-size: 0.75rem;
            color: #6366f1;
            font-weight: 600;
            display: inline-block;
            word-break: break-all;
        }
    </style>
</head>
<body>

    <div class="card-premium">
        <div class="icon-success">
            <i class="fas fa-check-double text-3xl text-white"></i>
        </div>

        <h1 class="text-3xl gradient-text font-extrabold tracking-tight mb-2">Website Siap!</h1>
        <p class="text-gray-500 text-xs mb-8 font-medium">
            Website berhasil dibuat oleh <span class="text-indigo-600 font-bold">Cahyo SR</span>
        </p>

        <!-- Link Preview -->
        <div>
            <label class="label-style">
                <i class="fas fa-link mr-1 text-gray-400 text-xs"></i> Link Preview
            </label>
            <div class="input-group" onclick="copyField('link-nebar', 'Link Preview')">
                <input id="link-nebar" type="text" readonly class="input-box" value="https://<?= htmlspecialchars($domain) ?>/<?= htmlspecialchars($subdomain) ?>">
                <div class="text-right mt-1">
                    <span class="text-[10px] text-gray-400">klik untuk salin</span>
                </div>
            </div>
        </div>

        <!-- Link Admin -->
        <div>
            <label class="label-style">
                <i class="fas fa-cog mr-1 text-gray-400 text-xs"></i> Link Setting
            </label>
            <div class="input-group" onclick="copyField('link-setting', 'Link Admin')">
                <input id="link-setting" type="text" readonly class="input-box" value="https://<?= htmlspecialchars($domain) ?>/<?= htmlspecialchars($subdomain) ?>/update.php">
                <div class="text-right mt-1">
                    <span class="text-[10px] text-gray-400">klik untuk salin</span>
                </div>
            </div>
        </div>

        <!-- Shortened URL -->
        <div>
            <label class="label-style">
                <i class="fas fa-shortcake mr-1 text-gray-400 text-xs"></i> LINK NEBAR
            </label>
            <div class="input-group" onclick="copyField('link-short', 'Short Link')">
                <input id="link-short" type="text" readonly class="input-box text-indigo-600 font-semibold" value="<?= htmlspecialchars($shortenedURL) ?>">
                <div class="text-right mt-1">
                    <span class="text-[10px] text-gray-400">klik untuk salin</span>
                </div>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <button onclick="copyShortLink()" class="btn-gradient mt-4">
            <i class="fas fa-copy"></i> Salin Link Nebar
        </button>
        
        <button onclick="bukaSetting()" class="btn-outline">
            <i class="fas fa-cog mr-2"></i> BUKA SETTING
        </button>

        <!-- Divider -->
        <div class="divider">
            <span>Powered by</span>
        </div>

        <!-- Footer -->
        <footer>
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">
                <a href="https://chat.whatsapp.com/C5JVo3L3OM61nfP55UYGjw?mode=gi_t" class="text-indigo-500 hover:text-indigo-600 transition">©Dikzx Nesia |</a>
            </p>
        </footer>
    </div>

    <div id="toast">Berhasil disalin!</div>

    <script>
        function showToast(msg) {
            const toast = document.getElementById('toast');
            toast.textContent = msg;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 2500);
        }

        function copyField(fieldId, fieldName) {
            const input = document.getElementById(fieldId);
            const value = input.value;
            
            navigator.clipboard.writeText(value)
                .then(() => showToast(`${fieldName} berhasil disalin!`))
                .catch(() => showToast(`Gagal menyalin ${fieldName}`));
        }

        function copyShortLink() {
            const shortUrl = document.getElementById("link-short").value;
            navigator.clipboard.writeText(shortUrl)
                .then(() => showToast("Link pendek berhasil disalin!"))
                .catch(() => showToast("Gagal menyalin link."));
        }

        function bukaSetting() {
            const subdomain = "<?= htmlspecialchars($subdomain) ?>";
            const domain = "<?= htmlspecialchars($domain) ?>";
            window.location.href = `https://${domain}/${subdomain}/update.php`;
        }

        // Tambahkan efek klik pada input group
        document.querySelectorAll('.input-group').forEach(group => {
            group.style.cursor = 'pointer';
        });
    </script>

</body>
</html>